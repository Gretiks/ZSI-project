import { NextApiRequest, NextApiResponse } from "next";
import getConnection from "@/lib/db"; // zakładam, że masz ten plik jak wcześniej

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method Not Allowed" });
  }

  const { title, category, description, access, id_author } = req.body;

  if (!title || !category || !description || !id_author) {
    return res.status(400).json({ message: "Brakuje wymaganych danych" });
  }

  try {
    const conn = await getConnection();

    const [result] = await conn.execute(
      `INSERT INTO quizzes (title, category, description, created_at, updated_at, access, id_author)
       VALUES (?, ?, ?, NOW(), NOW(), ?, ?)`,
      [title, category, description, access, id_author]
    );

    conn.release();

    return res.status(200).json({ message: "Quiz zapisany" });
  } catch (err) {
    console.error("Błąd zapisu quizu:", err);
    return res.status(500).json({ message: "Błąd serwera" });
  }
}
