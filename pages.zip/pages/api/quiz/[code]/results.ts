// endpoint wynikó
