import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Footer from "@/components/footer";
import NavBar from "@/components/navbar/navbar";
import Button from "@/components/Reusable/Button";

const Createquiz = () => {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [questions, setQuestions] = useState<any[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) router.push("/auth");
  }, []);

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        text: "",
        type: "one",
        answers: [
          { text: "", is_correct: false },
          { text: "", is_correct: false },
          { text: "", is_correct: false },
          { text: "", is_correct: false },
        ],
      },
    ]);
  };

  const handleQuestionChange = (index: number, field: string, value: any) => {
    const updated = [...questions];
    updated[index][field] = value;
    setQuestions(updated);
  };

  const handleAnswerChange = (qIdx: number, aIdx: number, field: string, value: any) => {
    const updated = [...questions];
    updated[qIdx].answers[aIdx][field] = value;
    setQuestions(updated);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setMessage(null);

    try {
      const quizRes = await fetch("/api/createquiz/createquiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          category,
          description,
          access: "private",
          id_author: "niger",
        }),
      });

      if (!quizRes.ok) throw new Error("Błąd podczas zapisu quizu.");

      const quizId = await quizRes.json().then((data) => data.quizId);

      for (const question of questions) {
        const questionRes = await fetch("/api/createquiz/createquestion", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: question.text,
            type: question.type,
            time_limit: "00:01:00",
            quiz_id: 12,
          }),
        });

        const questionId = await questionRes.json().then((data) => data.questionId);

        for (const answer of question.answers) {
          await fetch("/api/createquiz/createanswer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              text: answer.text,
              is_correct: answer.is_correct ? 1 : 0,
              question_id: 1,
            }),
          });
        }
      }

      setMessage("Quiz i pytania zostały zapisane!");
      setTitle("");
      setCategory("");
      setDescription("");
      setQuestions([]);
    } catch (err: any) {
      setMessage(err.message || "Coś poszło nie tak.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient min-h-screen flex flex-col">
      <NavBar />
      <div className="flex-1 flex items-center justify-center">
        <div className="w-full max-w-4xl mx-auto p-6 bg-white bg-opacity-90 rounded shadow flex flex-col gap-5">
          <h2 className="text-2xl font-bold text-center">Stwórz nowy quiz</h2>

          <input
            type="text"
            placeholder="Tytuł quizu"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="p-3 border rounded text-black"
          />

          <input
            type="text"
            placeholder="Kategoria quizu"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="p-3 border rounded text-black"
          />

          <textarea
            placeholder="Opis quizu"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            className="p-3 border rounded text-black"
          />

          <Button
            onClick={handleAddQuestion}
            text="Dodaj pytanie"
          />

          {questions.map((q, qIdx) => (
            <div key={qIdx} className="p-4 border rounded bg-gray-100">
              <input
                type="text"
                placeholder="Treść pytania"
                value={q.text}
                onChange={(e) => handleQuestionChange(qIdx, "text", e.target.value)}
                className="p-2 mb-2 w-full rounded text-black"
              />

              <select
                value={q.type}
                onChange={(e) => handleQuestionChange(qIdx, "type", e.target.value)}
                className="p-2 mb-2 w-full rounded text-black"
              >
                <option value="one">Odpowiedź pojedyncza</option>
                <option value="multi">Wielokrotny wybór</option>
                <option value="t/f">Prawda / Fałsz</option>
              </select>

              {q.type === "t/f" ? (
                [true, false].map((val, aIdx) => (
                  <label key={aIdx} className="block mb-1">
                    <input
                      type="radio"
                      name={`truefalse-${qIdx}`}
                      checked={q.answers[aIdx]?.is_correct || false}
                      onChange={() => {
                        const updated = [...q.answers];
                        updated[0] = { text: "Prawda", is_correct: val === true };
                        updated[1] = { text: "Fałsz", is_correct: val === false };
                        handleQuestionChange(qIdx, "answers", updated);
                      }}
                    /> {val ? "Prawda" : "Fałsz"}
                  </label>
                ))
              ) : (
                q.answers.map((a, aIdx) => (
                  <div key={aIdx} className="flex items-center mb-1">
                    <input
                      type="checkbox"
                      checked={a.is_correct}
                      onChange={(e) => handleAnswerChange(qIdx, aIdx, "is_correct", e.target.checked)}
                      className="mr-2"
                    />
                    <input
                      type="text"
                      placeholder={`Odpowiedź ${aIdx + 1}`}
                      value={a.text}
                      onChange={(e) => handleAnswerChange(qIdx, aIdx, "text", e.target.value)}
                      className="p-1 border rounded text-black flex-1"
                    />
                  </div>
                ))
              )}
            </div>
          ))}

          <Button
            onClick={handleSubmit}
            text="Dodaj Quiz"
          />


          {message && <p className="text-center text-sm text-gray-700">{message}</p>}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Createquiz;
